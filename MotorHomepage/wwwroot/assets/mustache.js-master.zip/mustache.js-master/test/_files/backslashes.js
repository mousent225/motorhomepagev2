({
  value: "\\abc"
})
